package com.alex.app.model

import androidx.compose.ui.graphics.vector.ImageVector

data class ContentItem(
    val title: String,
    val subtitle: String,
    val badge: String = "DEMO",
    val icon: ImageVector? = null
)

data class AppCategory(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector
)
