package com.alex.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import com.alex.app.ui.AlexApp
import com.alex.app.ui.theme.AlexTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AlexTheme {
                Surface(modifier = androidx.compose.ui.Modifier.fillMaxSize()) {
                    AlexApp()
                }
            }
        }
    }
}
