package com.alex.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alex.app.data.DemoRepository
import com.alex.app.model.AppCategory
import com.alex.app.model.ContentItem

private enum class MainTab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    TRENDING("Trending", Icons.Filled.TrendingUp),
    NEW("New", Icons.Filled.FiberNew),
    FAVORITES("Favorites", Icons.Filled.Favorite),
    PROFILE("Profile", Icons.Filled.AccountCircle)
}

@Composable
fun AlexApp() {
    var tab by remember { mutableStateOf(MainTab.HOME) }
    var openedCategory by remember { mutableStateOf<AppCategory?>(null) }
    var searchOpen by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (openedCategory == null && !searchOpen) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f),
                    tonalElevation = 8.dp
                ) {
                    MainTab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label, maxLines = 1) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            AnimatedContent(
                targetState = Triple(tab, openedCategory, searchOpen),
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen"
            ) { state ->
                when {
                    state.third -> SearchScreen(onBack = { searchOpen = false })
                    state.second != null -> CategoryScreen(
                        category = state.second!!,
                        onBack = { openedCategory = null }
                    )
                    else -> when (state.first) {
                        MainTab.HOME -> HomeScreen(
                            onSearch = { searchOpen = true },
                            onCategory = { openedCategory = it }
                        )
                        MainTab.TRENDING -> FeedScreen(
                            title = "Trending",
                            subtitle = "Popular demo content across ALEX APP",
                            icon = Icons.Filled.TrendingUp,
                            onBack = null
                        )
                        MainTab.NEW -> FeedScreen(
                            title = "New",
                            subtitle = "Recently added demo content",
                            icon = Icons.Filled.FiberNew,
                            onBack = null
                        )
                        MainTab.FAVORITES -> EmptyFavorites()
                        MainTab.PROFILE -> ProfileScreen()
                    }
                }
            }
        }
    }
}

@Composable
private fun TopBar(
    onSearch: (() -> Unit)? = null,
    onBack: (() -> Unit)? = null,
    title: String = "ALEX APP"
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, "Back")
            }
            Spacer(Modifier.width(4.dp))
        }
        Text(
            title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.weight(1f)
        )
        if (onSearch != null) {
            IconButton(onClick = onSearch) {
                Icon(Icons.Filled.Search, "Search")
            }
        }
        Icon(Icons.Filled.Bolt, "ALEX", tint = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun HomeScreen(
    onSearch: () -> Unit,
    onCategory: (AppCategory) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 18.dp)
    ) {
        TopBar(onSearch = onSearch)

        Column(Modifier.padding(horizontal = 20.dp)) {
            Text("Welcome back", style = MaterialTheme.typography.titleMedium)
            Text(
                "Discover your next favorite thing.",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(18.dp))

            SectionTitle("Featured")
            HorizontalCards(DemoRepository.homeFeatured)

            SectionTitle("Recommended")
            HorizontalCards(DemoRepository.itemsFor("entertainment"))

            SectionTitle("Categories")
            CategoryGrid(DemoRepository.categories, onCategory)

            Spacer(Modifier.height(10.dp))
            DemoNotice()
        }
    }
}

@Composable
private fun CategoryGrid(
    categories: List<AppCategory>,
    onCategory: (AppCategory) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        categories.chunked(2).forEach { row ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                row.forEach { category ->
                    CategoryCard(
                        category = category,
                        modifier = Modifier.weight(1f),
                        onClick = { onCategory(category) }
                    )
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun CategoryCard(
    category: AppCategory,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(116.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .72f)
        )
    ) {
        Column(
            Modifier.padding(15.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(category.icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(
                category.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CategoryScreen(category: AppCategory, onBack: () -> Unit) {
    val items = remember(category.id) { DemoRepository.itemsFor(category.id) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 20.dp)
    ) {
        TopBar(title = category.title, onBack = onBack)
        Text(
            category.description,
            modifier = Modifier.padding(horizontal = 20.dp),
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))

        if (items.isEmpty()) {
            EmptyState("Nothing here yet", "This section is ready for future content.")
        } else {
            SectionTitle("Featured")
            ContentList(items.take(2))
            SectionTitle("Latest")
            ContentList(items)
            SectionTitle("Popular")
            ContentList(items.reversed())
            SectionTitle("Recommended")
            ContentList(items.shuffled())
        }

        if (category.id == "trading") {
            Spacer(Modifier.height(10.dp))
            DemoNotice(
                text = "Trading sections are educational/demo only. No real-money gambling, betting, or live brokerage execution is included."
            )
        } else if (category.id == "apps") {
            Spacer(Modifier.height(10.dp))
            DemoNotice(
                text = "External links are placeholders until verified URLs are added. No fake URLs are included."
            )
        }
    }
}

@Composable
private fun FeedScreen(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onBack: (() -> Unit)?
) {
    val items = listOf(
        ContentItem("Featured $title", "Demo content card", "DEMO", icon),
        ContentItem("Popular Pick", "Demo popular item", "DEMO", Icons.Filled.Whatshot),
        ContentItem("Fresh Discovery", "Demo newly surfaced item", "DEMO", Icons.Filled.AutoAwesome),
        ContentItem("Community Favorite", "Demo social-style card", "DEMO", Icons.Filled.Favorite)
    )
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        TopBar(title = title, onBack = onBack)
        Text(subtitle, Modifier.padding(horizontal = 20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
        ContentList(items)
        Spacer(Modifier.height(12.dp))
        DemoNotice()
    }
}

@Composable
private fun SearchScreen(onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val all = remember {
        DemoRepository.categories.flatMap { DemoRepository.itemsFor(it.id) }
    }
    val results = if (query.isBlank()) emptyList() else all.filter {
        it.title.contains(query, true) || it.subtitle.contains(query, true)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        TopBar(title = "Search", onBack = onBack)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            placeholder = { Text("Search ALEX APP") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Filled.Clear, "Clear")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(18.dp)
        )
        Spacer(Modifier.height(18.dp))
        if (query.isBlank()) {
            EmptyState("Search everything", "Try entertainment, anime, gaming, trading or memes.")
        } else if (results.isEmpty()) {
            EmptyState("No demo results", "Real content will appear here when a content source/API is connected.")
        } else {
            SectionTitle("Results")
            ContentList(results.take(12))
        }
    }
}

@Composable
private fun ProfileScreen() {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 20.dp)
    ) {
        TopBar(title = "Profile")
        Column(Modifier.padding(horizontal = 20.dp)) {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        modifier = Modifier.size(64.dp),
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = .18f)
                    ) {
                        Icon(
                            Icons.Filled.AccountCircle,
                            null,
                            modifier = Modifier.padding(10.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("ALEX User", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text("Demo profile", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            ProfileRow(Icons.Filled.Favorite, "Favorites", "Saved content will appear here")
            ProfileRow(Icons.Filled.Settings, "Settings", "App preferences and controls")
            ProfileRow(Icons.Filled.DarkMode, "Dark mode", "Enabled by default")
            ProfileRow(Icons.Filled.Info, "About", "ALEX APP • Demo build")
            ProfileRow(Icons.Filled.PersonAdd, "Future accounts", "Ready for future account integration")
            Spacer(Modifier.height(12.dp))
            DemoNotice()
        }
    }
}

@Composable
private fun ProfileRow(icon: ImageVector, title: String, subtitle: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .6f))
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Filled.ChevronRight, null)
        }
    }
}

@Composable
private fun HorizontalCards(items: List<ContentItem>) {
    Row(
        Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items.forEach { item ->
            ContentCard(item, Modifier.width(205.dp))
        }
    }
}

@Composable
private fun ContentList(items: List<ContentItem>) {
    Column(
        Modifier.padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items.forEach { item -> ContentCard(item, Modifier.fillMaxWidth()) }
    }
}

@Composable
private fun ContentCard(item: ContentItem, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.heightIn(min = 92.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .72f))
    ) {
        Row(
            Modifier.padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                modifier = Modifier.size(56.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.primary.copy(alpha = .13f)
            ) {
                Icon(
                    item.icon ?: Icons.Filled.PlayArrow,
                    null,
                    modifier = Modifier.padding(15.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(item.title, fontWeight = FontWeight.Bold)
                Text(
                    item.subtitle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall
                )
            }
            AssistChip(
                onClick = {},
                label = { Text(item.badge, style = MaterialTheme.typography.labelSmall) }
            )
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 20.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Text("View all", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun DemoNotice(
    text: String = "DEMO CONTENT — ALEX APP is ready for real APIs/content sources, but no live content is being claimed in this build."
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = .08f)
        )
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Text(
                text,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun EmptyFavorites() {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.FavoriteBorder,
            null,
            modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(14.dp))
        Text("Your favorites are empty", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "Saved content will appear here.",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun EmptyState(title: String, message: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(36.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Filled.SearchOff,
            null,
            modifier = Modifier.size(52.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
