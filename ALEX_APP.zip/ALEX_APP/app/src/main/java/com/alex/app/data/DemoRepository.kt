package com.alex.app.data

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import com.alex.app.model.AppCategory
import com.alex.app.model.ContentItem

object DemoRepository {
    val categories = listOf(
        AppCategory("entertainment", "Entertainment", "Movies, music, shorts & more", Icons.Filled.Movie),
        AppCategory("gaming", "Gaming", "Games, videos, news & popular picks", Icons.Filled.SportsEsports),
        AppCategory("trading", "Trading", "Forex, crypto, stocks & learning", Icons.Filled.ShowChart),
        AppCategory("anime", "Anime", "Anime, characters & wallpapers", Icons.Filled.AutoAwesome),
        AppCategory("videos", "Videos", "Shorts, popular, trending & new", Icons.Filled.PlayCircle),
        AppCategory("images", "Images & Wallpapers", "HD images, art & wallpapers", Icons.Filled.Image),
        AppCategory("funny", "Funny & Memes", "Memes, funny images & videos", Icons.Filled.EmojiEmotions),
        AppCategory("trending", "Trending / Popular", "What is popular in ALEX APP", Icons.Filled.TrendingUp),
        AppCategory("new", "New", "Recently added demo content", Icons.Filled.FiberNew),
        AppCategory("characters", "Characters", "Anime & gaming character profiles", Icons.Filled.Person),
        AppCategory("favorites", "Favorites", "Your saved content", Icons.Filled.Favorite),
        AppCategory("apps", "Apps / Links", "Useful services and external links", Icons.Filled.Link),
        AppCategory("profile", "Profile", "Preferences, settings & account", Icons.Filled.AccountCircle)
    )

    fun itemsFor(categoryId: String): List<ContentItem> {
        val common = when (categoryId) {
            "entertainment" -> listOf(
                ContentItem("Featured Movies", "Demo movie discovery collection", icon = Icons.Filled.Movie),
                ContentItem("Music Picks", "Demo playlists and artist highlights", icon = Icons.Filled.MusicNote),
                ContentItem("Short Videos", "Demo entertainment shorts", icon = Icons.Filled.PlayArrow),
                ContentItem("Entertainment Recs", "Personalized-ready demo section", icon = Icons.Filled.Star)
            )
            "gaming" -> listOf(
                ContentItem("Popular Games", "Demo game catalog", icon = Icons.Filled.SportsEsports),
                ContentItem("Gaming Videos", "Demo gameplay feed", icon = Icons.Filled.VideogameAsset),
                ContentItem("Gaming News", "Demo news cards", icon = Icons.Filled.Newspaper),
                ContentItem("Future Features", "Expandable game integrations", icon = Icons.Filled.Extension)
            )
            "trading" -> listOf(
                ContentItem("Learning Hub", "Demo lessons: risk, charts & market basics", icon = Icons.Filled.School),
                ContentItem("Forex", "Educational market section", icon = Icons.Filled.CurrencyExchange),
                ContentItem("Crypto", "Educational crypto section", icon = Icons.Filled.CurrencyBitcoin),
                ContentItem("Stocks", "Educational equity section", icon = Icons.Filled.ShowChart),
                ContentItem("Charts & Analysis", "Demo chart area — not live market data", icon = Icons.Filled.Analytics),
                ContentItem("Practice Mode", "Paper/demo practice only; no real-money betting", icon = Icons.Filled.Science)
            )
            "anime" -> listOf(
                ContentItem("Popular Anime", "Demo anime discovery", icon = Icons.Filled.AutoAwesome),
                ContentItem("Characters", "Demo character collection", icon = Icons.Filled.Person),
                ContentItem("Anime Wallpapers", "Demo wallpaper gallery", icon = Icons.Filled.Wallpaper),
                ContentItem("Anime Videos", "Demo video collection", icon = Icons.Filled.PlayCircle)
            )
            "videos" -> listOf(
                ContentItem("Short Videos", "Demo short-form feed", icon = Icons.Filled.SlowMotionVideo),
                ContentItem("Popular Videos", "Demo popular feed", icon = Icons.Filled.Whatshot),
                ContentItem("Trending Videos", "Demo trending feed", icon = Icons.Filled.TrendingUp),
                ContentItem("New Videos", "Demo newly added feed", icon = Icons.Filled.FiberNew)
            )
            "images" -> listOf(
                ContentItem("Anime Wallpapers", "Demo HD collection", icon = Icons.Filled.Wallpaper),
                ContentItem("Gaming Wallpapers", "Demo gaming collection", icon = Icons.Filled.Gamepad),
                ContentItem("Character Images", "Demo character art", icon = Icons.Filled.Person),
                ContentItem("HD Wallpapers", "Demo high-resolution gallery", icon = Icons.Filled.Image)
            )
            "funny" -> listOf(
                ContentItem("Funny Images", "Demo funny gallery", icon = Icons.Filled.Image),
                ContentItem("Memes", "Demo meme collection", icon = Icons.Filled.EmojiEmotions),
                ContentItem("Funny Videos", "Demo comedy videos", icon = Icons.Filled.PlayCircle),
                ContentItem("Trending Memes", "Demo trending memes", icon = Icons.Filled.Whatshot)
            )
            "characters" -> listOf(
                ContentItem("Character Profiles", "Demo profile cards", icon = Icons.Filled.Person),
                ContentItem("Anime Characters", "Demo anime characters", icon = Icons.Filled.AutoAwesome),
                ContentItem("Gaming Characters", "Demo gaming characters", icon = Icons.Filled.SportsEsports),
                ContentItem("Favorite Characters", "Saved-ready demo collection", icon = Icons.Filled.Favorite)
            )
            "apps" -> listOf(
                ContentItem("Useful Apps", "Placeholder section for verified app links", icon = Icons.Filled.Apps),
                ContentItem("Useful Services", "Add trusted service URLs later", icon = Icons.Filled.Public),
                ContentItem("External Links", "No fake URLs are included", icon = Icons.Filled.Link)
            )
            else -> listOf(
                ContentItem("Featured", "Demo content placeholder", icon = Icons.Filled.Star),
                ContentItem("Latest", "Demo latest content placeholder", icon = Icons.Filled.FiberNew),
                ContentItem("Popular", "Demo popular content placeholder", icon = Icons.Filled.Whatshot),
                ContentItem("Recommended", "Demo recommendations placeholder", icon = Icons.Filled.Recommend)
            )
        }
        return common
    }

    val homeFeatured = listOf(
        ContentItem("ALEX Spotlight", "Featured demo content", "FEATURED", Icons.Filled.AutoAwesome),
        ContentItem("Trending Now", "Demo trend collection", "TRENDING", Icons.Filled.TrendingUp),
        ContentItem("Fresh Drops", "Demo newly added content", "NEW", Icons.Filled.FiberNew)
    )
}
