package com.alex.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AlexDark = darkColorScheme(
    primary = Color(0xFFB388FF),
    onPrimary = Color(0xFF1A1028),
    secondary = Color(0xFF7DD3FC),
    tertiary = Color(0xFFFF8FB1),
    background = Color(0xFF08090C),
    onBackground = Color(0xFFF4F1F8),
    surface = Color(0xFF111318),
    onSurface = Color(0xFFF4F1F8),
    surfaceVariant = Color(0xFF1B1D24),
    onSurfaceVariant = Color(0xFFB9B7C2),
    outline = Color(0xFF343640)
)

@Composable
fun AlexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AlexDark,
        typography = Typography(),
        content = content
    )
}
