# ALEX APP release rules.
# Add rules here when real API/SDK integrations are introduced.
