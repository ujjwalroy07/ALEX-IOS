# ALEX APP

A complete single-app Android project for **ALEX APP**, built with Kotlin and Jetpack Compose.

## Included

- Dark premium mobile-first UI
- Bottom navigation: Home, Trending, New, Favorites, Profile
- Search screen
- 13 expandable categories:
  - Entertainment
  - Gaming
  - Trading
  - Anime
  - Videos
  - Images & Wallpapers
  - Funny & Memes
  - Trending / Popular
  - New
  - Characters
  - Favorites
  - Apps / Links
  - Profile
- Category detail screens with Featured / Latest / Popular / Recommended sections
- Loading-ready architecture and empty/error-style states
- Demo content clearly labeled
- Trading is educational/demo only; no real-money gambling or betting
- No fake external URLs
- Modular repository/model/UI structure for future API/database integrations

## Requirements

- Android Studio with Android SDK 35
- JDK 17
- Internet access on first Gradle sync so Android Studio can download dependencies

## Open the project

1. Extract `ALEX_APP.zip`.
2. Open the extracted `ALEX_APP` folder in Android Studio.
3. Let Gradle sync/download dependencies.
4. Connect an Android phone with USB debugging or create an emulator.
5. Press **Run**.

## Generate a debug APK

From Android Studio:

**Build > Generate App Bundles or APKs > Generate APKs**

The debug APK will normally be generated at:

`app/build/outputs/apk/debug/app-debug.apk`

## Generate a signed release APK

1. Select **Build > Generate Signed App Bundle / APK**.
2. Choose **APK**.
3. Create/select a keystore.
4. Select the `release` build type.
5. Finish the wizard.

The signed APK will normally be under:

`app/build/outputs/apk/release/`

## Architecture notes

`com.alex.app.data.DemoRepository` is the single demo content source. Replace or extend it later with repository interfaces backed by APIs, Room, Firebase, or another backend without changing the navigation structure.

`AppModels.kt` contains reusable content/category models.

`AlexApp.kt` contains the Compose UI/navigation shell. For a larger production app, individual screens can be split into separate files/packages while keeping the same data contracts.

No live content API is connected in this build, so demo data is intentionally not presented as live.
